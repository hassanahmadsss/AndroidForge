package com.lamoji.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputContentInfo;
import android.content.ClipDescription;
import android.graphics.drawable.Drawable;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.Button;
import android.widget.ScrollView;
import android.view.Gravity;
import android.util.TypedValue;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.content.Intent;
import androidx.core.content.FileProvider;
import java.io.*;
import java.util.*;

public class LamojiImeService extends InputMethodService {
  LinearLayout root; String active="LAMO";
  String[] names={"01_happy","02_laughing","03_heart_eyes","04_kiss","05_joy_peace","06_party","07_cool","08_surprised","09_crying","10_angry","11_thinking","12_sad","13_worried","14_sleepy","15_sick","16_cookie"};
  @Override public View onCreateInputView(){
    root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(6),dp(5),dp(6),dp(5));
    LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
    Button boy=new Button(this); boy.setText("LAMO 💙"); boy.setOnClickListener(v->{active="LAMO";populate();});
    Button girl=new Button(this); girl.setText("LAMA 💗"); girl.setOnClickListener(v->{active="LAMA";populate();});
    tabs.addView(boy,new LinearLayout.LayoutParams(0,dp(44),1)); tabs.addView(girl,new LinearLayout.LayoutParams(0,dp(44),1)); root.addView(tabs);
    populate(); return root;
  }
  void populate(){
    if(root==null)return; while(root.getChildCount()>1)root.removeViewAt(1);
    ScrollView scroll=new ScrollView(this); GridLayout grid=new GridLayout(this); grid.setColumnCount(4); grid.setPadding(dp(2),dp(4),dp(2),dp(4));
    for(String n:names){String file=active+"_"+n+"_128.png"; ImageButton b=new ImageButton(this); b.setScaleType(ImageButton.ScaleType.FIT_CENTER); b.setBackgroundColor(0x00000000); try{InputStream is=getAssets().open("stickers/"+file); Bitmap bm=BitmapFactory.decodeStream(is); b.setImageDrawable(new BitmapDrawable(getResources(),bm)); is.close();}catch(Exception e){b.setContentDescription(file);} GridLayout.LayoutParams lp=new GridLayout.LayoutParams(); lp.width=dp(74);lp.height=dp(74);lp.setMargins(dp(3),dp(3),dp(3),dp(3)); grid.addView(b,lp); b.setOnClickListener(v->insertSticker(file)); }
    scroll.addView(grid); root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(220)));
  }
  void insertSticker(String assetName){
    try{
      File dir=new File(getCacheDir(),"stickers");dir.mkdirs(); File out=new File(dir,assetName);
      InputStream in=getAssets().open("stickers/"+assetName); FileOutputStream fos=new FileOutputStream(out); byte[] buf=new byte[8192];int len;while((len=in.read(buf))>0)fos.write(buf,0,len);fos.close();in.close();
      Uri uri=FileProvider.getUriForFile(this,"com.lamoji.keyboard.files",out);
      InputConnection ic=getCurrentInputConnection(); if(ic==null)return;
      if(Build.VERSION.SDK_INT>=25){ InputContentInfo info=new InputContentInfo(uri,new ClipDescription("LAMOJI sticker",new String[]{"image/png"}),null); ic.commitContent(info,InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION,null); }
      else { ic.commitText("[LAMOJI sticker: "+assetName+"]",1); }
    }catch(Exception e){ if(getCurrentInputConnection()!=null)getCurrentInputConnection().commitText("[LAMOJI]",1); }
  }
  int dp(int x){return (int)TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,x,getResources().getDisplayMetrics());}
}
